
from tensorflow.keras import layers, models
import numpy as np
model = models.Sequential([
    layers.Input(shape=(48,48,1)),
    layers.Conv2D(16,3,activation='relu'),
    layers.MaxPool2D(2),
    layers.Conv2D(32,3,activation='relu'),
    layers.MaxPool2D(2),
    layers.Flatten(),
    layers.Dense(32, activation='relu'),
    layers.Dense(4, activation='softmax')
])
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
# create tiny synthetic dataset
X = np.random.rand(200,48,48,1).astype('float32')
y = np.random.randint(0,4,size=(200,))
model.fit(X,y,epochs=3,verbose=2)
model.save('emotion_model.h5')
print('Saved emotion_model.h5')
