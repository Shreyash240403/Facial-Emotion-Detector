# Facial Emotion Detection (OpenCV + Keras)
A minimal demo that uses OpenCV to capture webcam frames and a tiny Keras CNN to classify emotions.
The included model is a small network trained for a few iterations on synthetic data so inference works locally.
Labels: ['Angry','Happy','Neutral','Sad']

## Run
```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python run_emotion_cam.py
```
Press 'q' to quit the webcam window.